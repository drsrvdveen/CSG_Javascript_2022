var keverX;
var keverY;

function preload() {
  kever = loadImage("images/sprites/kever.png");
}

function setup() {
  canvas = createCanvas(450,450);
  background('orange');
  canvas.parent('processing');
  keverX = 150;
  keverY = 100;
}

function draw() {
  noStroke();
  background('orange');
  image(kever,keverX,keverY,30,30);
  text("breete is 30",20,20)
}