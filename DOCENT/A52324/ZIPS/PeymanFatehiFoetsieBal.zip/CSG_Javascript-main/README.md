# Augustinuscollege informatica

Dit is een *repository* om te werken in Github Codespaces of [GitPod](https://gitpod.io).
Voor de *status* van GitPod kijk je op [GitPodStatus](https://www.gitpodstatus.com).

## GEBRUIK met Github Pages

1. Zorg dat je een eigen *fork* (kopie) van deze omgeving maakt
1. Kies nu in **jouw** *repository* voor **<> Code** en vervolgens voor *Codespaces*
1. Maak je eigen *codespace* aan: even geduld!
1. Aan de slag! *Push* je updates regelmatig naar **GitHub** via *Source Control*

## GEBRUIK met GitPod

1. Zorg dat je een eigen *fork* (kopie) van deze omgeving maakt
1. Voeg nu in **jouw** *repository* in de adresbalk **vooraan** toe: *gitpod.io#* (laat het adres staan) gevolgd door enter
1. Even geduld: er wordt nu een eigen werkomgeving voor je gemaakt
1. Vergeet niet je project te *pinnen* onder *Workspaces*
1. Aan de slag! *Push* regelmatig naar **GitHub** via *Source Control*
